#include <iostream>
using namespace std;

int main() {
    int x;
    cout << "Enter an integer: ";
    cin >> x;

    cout << "x = " << x << endl;
    cout << "2x = " << 2 * x << endl;
    cout << "x^2 = " << x * x << endl;

    return 0;
}